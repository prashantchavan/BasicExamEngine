﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AjaxCall : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    [WebMethod]
    public static List<SalesData> getSalesData()
    {
        List<SalesData> salesDataList = new List<SalesData>();
        DAL dal = new DAL();
        DataSet ds = new DataSet();
        ds = dal.getSalesData("S");
        DataTable dt = ds.Tables[0];
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                int id = Convert.ToInt32(row["ID"]);
                string region = Convert.ToString(row["REGION"]);
                int sales = Convert.ToInt32(row["SALES"]);

                salesDataList.Add(new SalesData
                {
                    ID = id,
                    Region = region,
                    Sales = sales
                });
            }
        }

        return salesDataList;
    }
   
}