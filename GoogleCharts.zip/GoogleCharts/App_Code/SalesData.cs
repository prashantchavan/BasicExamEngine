﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SalesData
/// </summary>
public class SalesData
{
    public SalesData()
    {

    }

    public int ID { get; set; }
    public string Region { get; set; }
    public int Sales { get; set; }
    public string color { get; set; }


}