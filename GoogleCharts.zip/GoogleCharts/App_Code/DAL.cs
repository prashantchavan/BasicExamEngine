﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
/// <summary>
/// Summary description for DAL
/// </summary>
public class DAL
{
    string cs = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;
    public DAL()
    {
       
    }

    public DataSet getSalesData(String flag)
    {
        DataSet salesData = new DataSet();
        using (SqlConnection con = new SqlConnection(cs))
        {
            SqlCommand cmd = new SqlCommand("USP_SALES_DATA", con);
            cmd.Parameters.AddWithValue("@FLAG", flag);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(salesData);
        }
        return salesData;
    }
}