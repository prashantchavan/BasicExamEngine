﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class GoogleChartOldStyle : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        bindChart();
    }

    private void bindChart()
    {
        try
        {
            DAL dal = new DAL();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            StringBuilder strScript = new StringBuilder();

            ds = dal.getSalesData("S");
            if (ds.Tables.Count > 0)
            {
                dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {

                }
            }

        }
        catch (Exception)
        {

            throw;
        }
        
    }
}