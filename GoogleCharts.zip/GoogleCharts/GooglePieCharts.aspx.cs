﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;

public partial class GooglePieCharts : System.Web.UI.Page
{
    public string pieChartData = string.Empty;
    public string columnChartData = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        getPieChartData();
        getColumnChartData();
    }

    private void getColumnChartData()
    {
        DAL dal = new DAL();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        StringBuilder strColumnChartData = new StringBuilder();

        ds = dal.getSalesData("B");
        if (ds.Tables.Count > 0)
        {
            dt = ds.Tables[0];
            if (dt.Rows.Count > 0)
            {
                strColumnChartData.Append("[");
                strColumnChartData.Append("['Year', 'Sales', 'Expenses', 'Profit'],");

                foreach (DataRow row in dt.Rows)
                {
                    strColumnChartData.Append("['"+row["YEAR"] +"', "+row["SALES"] +", "+row["EXPENSE"] +", "+row["PROFIT"] +"],");
                }

                var index = strColumnChartData.ToString().LastIndexOf(',');
                if (index >= 0)
                    strColumnChartData.Remove(index, 1);

                strColumnChartData.Append("]");
                columnChartData = strColumnChartData.ToString();
            }
        }
    }

    protected void getPieChartData()
    {
        DAL dal = new DAL();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        StringBuilder strPieChartData = new StringBuilder();

        ds = dal.getSalesData("S");
        if (ds.Tables.Count > 0)
        {
            dt = ds.Tables[0];
            if (dt.Rows.Count > 0)
            {
                strPieChartData.Append("[");
                foreach (DataRow row in dt.Rows)
                {
                    strPieChartData.Append("['"+ row["REGION"]  +"', "+ row["SALES"] +"],");
                }

                var index = strPieChartData.ToString().LastIndexOf(',');
                if (index >= 0)
                    strPieChartData.Remove(index, 1);

                strPieChartData.Append("]");
                pieChartData = strPieChartData.ToString();
            }
        }
    }
}