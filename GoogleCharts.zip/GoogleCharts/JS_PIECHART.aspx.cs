﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class JS_PIECHART : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    [WebMethod]
    public static List<SalesData> getSalesData(List<string> aData)
    {
        List<SalesData> salesDataList = new List<SalesData>();
        string[] arrColor = new string[] { "#231F20", "#FFC200", "#F44937", "#16F27E", "#FC9775", "#5A69A6" };

        DAL dal = new DAL();
        DataSet ds = new DataSet();
        ds = dal.getSalesData(aData[0]);
        DataTable dt = ds.Tables[0];
        if (dt.Rows.Count > 0)
        {
            int indexCounter = 0;
            foreach (DataRow row in dt.Rows)
            {
                int id = Convert.ToInt32(row["ID"]);
                string region = Convert.ToString(row["REGION"]);
                int sales = Convert.ToInt32(row["SALES"]);

                salesDataList.Add(new SalesData
                {
                    ID = id,
                    Region = region,
                    Sales = sales,
                    color = arrColor[indexCounter]
                });

                indexCounter++;
            }
        }

        return salesDataList;

    }
}